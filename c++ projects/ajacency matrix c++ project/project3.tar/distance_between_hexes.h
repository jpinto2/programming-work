#ifndef DISTANCE_BETWEEN_HEXES_H
#define DISTANCE_BETWEEN_HEXES_H
int distance_between_hexes(unsigned int starthex, unsigned int endhex);
#endif
